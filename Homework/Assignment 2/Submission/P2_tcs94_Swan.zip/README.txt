Problem 1:
- I added an iterator to it. This was to ensure memory safety when performing certain traversals and operations on the linked list. This means you can only access the data in the numlinkedlist by using an iterator outside of the class.
- I added toString and equals to the class in order to help with testing.

Problem 2:
- I added a toString method for testing help
- For testing, I generated a lot of test cases and also tested the class by using the linked leetcode problem in my javadoc

Problem 3:
- I added a helper method called transfer in order to move the elements from the input stack to the output stack to ensure queue behavior is still observed
- I added a toString implementation for brevity and testing assistance
